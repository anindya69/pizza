"""pizza_delivery URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.8/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Add an import:  from blog import urls as blog_urls
    2. Add a URL to urlpatterns:  url(r'^blog/', include(blog_urls))
"""
from django.conf.urls import include, url
from django.contrib import admin
from pizza_delivery_app.views import *

urlpatterns = [
    url(r'^backend/', include(admin.site.urls)),

    url(r'^$', landing_page_handler, name="landing_page_handler"),
    url(r'^sign-up/', signup_handler, name="signup_handler"),
    url(r'^login/', login_handler, name="login_handler"),
    url(r'^logout/', logout_handler, name="logout_handler"),

    url(r'^user/menu/', menu_handler, name="menu_handler"),
    url(r'^user/reset-password/', reset_password_handler, name="reset_password_handler"),
    url(r'^user/', user_handler, name="user_handler"),

    url(r'^admin/', admin_handler, name="admin_handler"),

    url(r'^test/', test, name="test"),
]
