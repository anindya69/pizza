from django.db import models
from django.contrib.auth.models import User
from datetime import date

# Create your models here.
class PizzaFoodMenuDetails(models.Model):
	"""Stores all pizza information information"""
	name = models.TextField(max_length=500)
	image_link = models.CharField(max_length=250)
	details = models.TextField(max_length=500)
	price = models.IntegerField(null=False, default=0)
	is_veg = models.BooleanField(default=False)
	is_food = models.BooleanField(default=False)

	class Meta:
		db_table = 'pizza_food_menu'

	def __str__(self):
		return "%s - %s" % (self.name, self.price)


class CartData(models.Model):
	"""Stores cart data when user add or delete from cart information"""
	user = models.ForeignKey(User)
	pizza_food = models.ForeignKey(PizzaFoodMenuDetails)
	quantity = models.IntegerField(null=False, default=1)

	class Meta:
		db_table = 'cart_data'

	def __str__(self):
		return "%s - %s" % (self.user, self.quantity)

