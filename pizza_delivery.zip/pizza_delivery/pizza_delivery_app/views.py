from django.shortcuts import render, redirect, render_to_response
from django.http import HttpResponse

from django.conf import settings
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from pizza_delivery_app.models import *

import json
import time
import datetime

# Create your views here.
def landing_page_handler(request):
	if request.method == 'GET':
		return render(request, 'index.htm', {
			'company_name': settings.COMPANY_NAME,
		})

	else: return HttpResponse(json.dumps({'reason':'Bad Request'}), content_type="application/json")

# Delete all present sessions
# Both for brand and creators
def delete_sessions(request):
	for key in request.session.keys():
		try: del request.session[key]
		except: pass

# Logout user from current session
def logout_handler(request, redirect_required = None):
	logout(request)
	delete_sessions(request)

	if not redirect_required: return redirect('/')

# Get user by using their email address
def get_user_via_email(email):
	try: return User.objects.get(email=email)
	except User.DoesNotExist: pass
	return None

# Set session for brand and YouTuber both
def set_sessions(request, user):
	request.session['userId'] = user.id
	request.session['email'] = user.email
	request.session['userType'] = 'admin' if user.is_superuser else 'user'
	request.session['userFirstName'] = user.first_name
	request.session['userLastName'] = user.last_name		
	return True

# Logged in the user to system
def login_handler(request):
	if request.method == 'GET':
		if request.user.is_authenticated() and request.session.get('userType'):
			return redirect('/{}/menu/'.format(request.session.get('userType')))

		delete_sessions(request)
		return render(request, 'login.htm', {
			'company_name': settings.COMPANY_NAME
		})

	elif request.method == 'POST':
		message = ''
		email = ''
		password = ''
		try:
			# Checking the both email address and password has been passed or not
			if request.POST.get('email') and request.POST.get('password'):
				email = request.POST.get('email').strip()
				password = request.POST.get('password').strip()
				# Deleting all the existing sessions so that user get logout
				logout_handler(request, True)
				print 1
				# Now checking is there any user exist with this email address or not
				user = get_user_via_email(email)
				print user
				if user:
					# Authenticating the user via django own authentication service and check the user exist or not
					auth_user = authenticate(username=user.username, password=password)
					if auth_user:
						# Check the user is active or not(i.e. user have verified his email address or not)
						if auth_user.is_active:
							login(request, auth_user) # Making the user logged in
							status = True
							if set_sessions(request, user): return redirect('{}/menu/'.format(request.session.get('userType')))
							else: 
								message = "Something gone terribly wrong."
						else: 
							message = "Sorry, Your username and password is okay. But your profile is Inactive"
					else: 
						message = "Wrong Password."
				else: 
					message = "This email address is not registered"

			return render(request, 'login.htm', {
				'company_name': settings.COMPANY_NAME,
				'message': message,
				'status': False,
				'email': email,
				'password': password
			});

		except Exception as e: print e

# Convert time to UNIX time-stamp
def time_to_millis(timestamp = None, date_format = None):
	if timestamp: return int(round(time.mktime(time.strptime(timestamp, date_format))))
	else: return int(round(time.time() * 1000))

def get_user_via_email(email):
	try: return User.objects.get(email=email)
	except User.DoesNotExist: pass
	return None

def signup_handler(request):
	if request.method == 'GET':
		delete_sessions(request)
		return render(request, 'signup.htm', {
			'company_name': settings.COMPANY_NAME
		})

	elif request.method == 'POST':
		print request.POST
		status = False
		message = ''

		if request.POST.get('fname') and request.POST.get('lname') and request.POST.get('email') and request.POST.get('password'):
			email = request.POST.get('email').strip()
			password = request.POST.get('password').strip()
			fname = request.POST.get('fname').strip()
			lname = request.POST.get('lname').strip()

			user = get_user_via_email(email)
			if user:
				status = False
				message = 'The email address already exist'

			else:
				# Creating user profile in auth_user table
				new_user = User.objects.create_user(
					email.split('@')[0] + str(time_to_millis()), 
					email, 
					password
				)
				new_user.is_active = True
				new_user.is_staff = True
				new_user.first_name = fname
				new_user.last_name = lname
				new_user.save()

				status = True
				message = 'User Successfully Created'
			
		return render(request, 'signup.htm', {
			'company_name': settings.COMPANY_NAME,
			'status': status,
			'message': message,
			'email': email,
			'fname': fname,
			'lname': lname,
			'password': password
		})

def menu_handler(request):
	if not request.user.is_authenticated() or not request.session.get('userType'):
		delete_sessions(request)
		return redirect('/login/')

	all_menu = PizzaFoodMenuDetails.objects.all()
	return_object = {
		'food': [],
		'pizza': []
	}
	for menu in all_menu:
		temp_object = {
			'img': menu.image_link,
			'is_veg': menu.is_veg,
			'name': menu.name,
			'desc': menu.details,
			'price': menu.price,
			'id': menu.id
		}

		if not menu.is_food: return_object.get('pizza').append(temp_object)
		else: return_object.get('food').append(temp_object)

	return render(request, 'menu.htm', {
		'company_name': settings.COMPANY_NAME,
		'menu': return_object
	})

# This function to create dummy data to get started
def test(request):
	if settings.DEBUG:
		PizzaFoodMenuDetails.objects.create(
			name = 'The Large Veg Pizza',
			image_link = '/static/images/pizza1.jpg',
			details = 'This is a veg pizza',
			price = 150,
			is_veg = True,
			is_food = False
		)
		PizzaFoodMenuDetails.objects.create(
			name = 'The 2nd Pizza',
			image_link = '/static/images/pizza2.jpg',
			details = 'This is a non-veg pizza.',
			price = 160,
			is_veg = False,
			is_food = False
		)
		PizzaFoodMenuDetails.objects.create(
			name = 'Burger',
			image_link = '/static/images/food1.jpg',
			details = 'This is a burger',
			price = 200,
			is_veg = True,
			is_food = True
		)
		PizzaFoodMenuDetails.objects.create(
			name = '2nd Burger',
			image_link = '/static/images/food2.jpg',
			details = 'This is 2nd kind of burger.',
			price = 180,
			is_veg = False,
			is_food = True
		)

		return redirect('/login/')

	return redirect('/')

def reset_password_handler(request):
	pass

def user_handler(request):
	pass

def admin_handler(request):
	pass